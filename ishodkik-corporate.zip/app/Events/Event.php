<?php

namespace Corp\Events;

abstract class Event
{
    //
}
