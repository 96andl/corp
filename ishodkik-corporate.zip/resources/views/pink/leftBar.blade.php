<div class="sidebar group">
	{!! $content_leftBar !!}
</div>