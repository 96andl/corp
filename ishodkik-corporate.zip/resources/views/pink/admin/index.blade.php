@extends(config('settings.theme').'.layouts.admin')

@section('navigation')
	{!! $navigation !!}
@endsection

@section('footer')
	{!! $footer !!}
@endsection 