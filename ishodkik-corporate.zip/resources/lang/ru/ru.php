<?php
return [
	
	'latest_projects' => 'Последние работы',
	'from_blog' => 'Последние записи блога',
	'comments' => 'Комментарий|Комментария|Комментариев',
	'read_more' => ' Читать далее',
	'articles_no' => '<h2>Записей нет</h2>',
	'latest_projects' => 'Последние работы',
	'latest_comments' => 'Последние ответы'
	
	
];
?>